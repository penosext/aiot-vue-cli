<template>
  <text class="text">Now, let's use Vue.js to build your iot app</text>
</template>
<script>

export default {
  name: "HelloComponent",
  components: {},
  data() {
    return {
      msg:''
    };
  },
  methods: {
  },
};
</script>

<style lang="less" scoped>
@import "base.less";
</style>
